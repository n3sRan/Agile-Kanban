## Backend

### Controller层设计

1. **UserController**
   - `login`: 用户登录接口，处理登录逻辑，返回用户信息和token。
   - `register`: 用户注册接口，处理用户信息的保存。
2. **ProjectController**
   - `createProject`: 创建项目，接收项目名称、描述等信息，调用Service层保存项目信息。
   - `getProjects`: 获取用户可访问的项目列表，调用Service层获取数据。
3. **TaskController**
   - `createTask`: 在指定项目中创建任务，接收任务详情，调用Service层保存任务。
   - `getTasks`: 获取项目中的任务列表，可按状态过滤，调用Service层。
   - `updateTask`: 更新任务状态或详情，调用Service层处理。
   - `addComment`: 为任务添加评论，调用Service层保存评论。
   - `getComments`: 获取任务的所有评论，调用Service层。
   - `uploadAttachment`: 上传任务附件，调用Service层保存文件。

### Service层设计

1. **UserService**
   - `login`: 验证用户登录信息，生成token。
   - `register`: 保存用户信息，处理密码加密等。
2. **ProjectService**
   - `create`: 保存项目信息到数据库，返回项目ID。
   - `listProjects`: 从数据库获取用户可访问的项目列表。
3. **TaskService**
   - `create`: 在指定项目中创建任务，保存到数据库。
   - `list`: 获取项目中的任务列表，可按状态过滤。
   - `update`: 更新任务状态或详情。
   - `addComment`: 保存评论到数据库。
   - `listComments`: 获取任务的所有评论。
   - `uploadAttachment`: 保存附件到文件系统或云存储，并记录到数据库。

